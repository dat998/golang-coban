package extractlinks

const version = "0.0.2"

// Version returns the current 'extractlinks' version
func Version() string {
	return version
}
